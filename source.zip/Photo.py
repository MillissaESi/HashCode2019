

class Photo:

    def __init__(self,id,type, m, tags):
        self.id = id
        self.size = m
        self.tags = tags
        self.type = type


