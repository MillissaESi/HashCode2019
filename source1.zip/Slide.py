

class Slide:

    def __init__(self,list_id, tags):
        self.ID = list_id
        self.tags = tags

